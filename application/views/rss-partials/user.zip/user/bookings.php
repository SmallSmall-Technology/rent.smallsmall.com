				<div class="user-mainbar-content">
				    
				    <?php if(isset($bookings) && !empty($bookings)){ ?>

						<?php foreach($bookings as $booking => $book){ ?>

							<?php

								$CI =& get_instance();

								$property = $CI->get_property($book['propertyID']);

								$user = $CI->get_user($book['userID']);

								$transaction = $CI->get_transaction($book['bookingID']);
								
						        $next_rental = strtotime($rss_transaction['rent_expiration']);
						        
						        $today = strtotime(date('Y-m-d'));
								    

							?>
        					<div class="booking-slide green-tint">
        						<div class="booking-stat"><?php if($next_rental > $today){ echo "Current Booking"; }else{ echo "Expired Booking"; } ?></div>
        						<div class="booking-img-container">
        							<img src="<?php echo base_url().'uploads/properties/'.$property['imageFolder'].'/'.$property['featuredImg']; ?>" alt="rentsmallsmall property" />
        						</div>
        						<div class="booking-prop-info">
        							<div class="full-slits">
        								<div class="booking-info-desc">Property Info</div>
        								<div class="booking-info-dets"><?php echo $property['propertyTitle']; ?></div>
        							</div>
        							<div class="full-slits">
        								<div class="booking-info-desc">Property Type</div>
        								<div class="booking-info-dets"><?php echo $property['type']; ?></div>
        							</div>
        							<div class="full-slits">
        								<div class="booking-info-desc">Location</div>
        								<div class="booking-info-dets"><?php echo $property['address'].', '.$property['city']; ?></div>
        							</div>
    								<?php if($book['verified'] == 'yes'){ ?>
									    <?php if($transaction['status'] != 'approved'){ ?>
									    
        							            <div class="renew-button" ><a style="text-decoration:none;color:#00CDA4;" href="<?php echo base_url().'pay-now/'.$book['bookingID'].'/'.$transaction['payment_type']; ?>">Pay Now</a></div>
										        
        							    <?php }else{ ?>
        							    
        							            <div class="deactivated-renew-button" >Renew Rent</div>
        							            
        							    <?php } ?>
        							<?php } ?>
        						</div>
        						<div class="booking-payment-info">
        							<div class="full-slits">
        								<div class="payment-info-slits">
        									<div class="booking-info-desc">Payment Plan</div>
        									<div class="booking-info-dets"><?php echo $book['payment_plan']; ?></div>
        								</div>
        								<div class="payment-info-slits">
        									<div class="web-display switch-button switcharoo" id="switch-<?php echo $book['id'].'-'.$book['propertyID']; ?>">Switch plan</div>
        								</div>
        							</div>
        							<div class="full-slits">
        
        								<div class="payment-info-slits">
        									<div class="booking-info-desc">Rent</div>
        									<div class="booking-info-price"><span style="font-family:helvetica;font-weight:bold">&#x20A6;</span><?php echo number_format($property['price']); ?></div>
        								</div>
        								<div class="payment-info-slits">
        									
        								</div>
        							</div>
        							<div class="full-slits">
        								<div class="payment-info-slits">
        									<div class="booking-info-desc">Starts</div>
        									<div class="booking-info-dets"><?php echo date('d M, Y', strtotime($book['move_in_date'])); ?></div>
        								</div>
        								<div class="payment-info-slits">
        									<div class="booking-info-desc">Expires</div>
        									<div class="booking-info-dets"><?php echo date('d M, Y', strtotime(@$book['next_rental'])); ?></div>
        									
        								</div>
        							</div>
        							<?php if($transaction['payment_type'] == 'paystack' || $transaction['payment_type'] == 'transfer'){ ?>
											
										<?php if($book['verified'] == 'yes'){ ?>
										
										    <?php if($transaction['status'] == 'approved'){ ?>
										
											    <div class="renew-button" ><a style="text-decoration:none;color:#00CDA4;" href="<?php echo base_url().'renew-payment/'.$book['bookingID']; ?>">Renew Rent</a></div>
											    
											<?php } ?>
											
									    <?php } ?>
										
									<?php } ?>
								<div class="mobile-display mobile-btn-container">
								    
								    <div class="switch-button switcharoo" id="switch-<?php echo $book['id'].'-'.$book['propertyID']; ?>">Switch plan</div>
								    
								    <?php if($book['verified'] == 'yes'){ ?>
									    <?php if($transaction['status'] != 'approved'){ ?>
									    
        							            <div class="pay-now-button" ><a href="<?php echo base_url().'pay-now/'.$book['bookingID'].'/'.$transaction['payment_type']; ?>">Pay Now</a></div>
										        
        							    <?php }else{ ?>
        							    
        							            <div class="deactivated-renew-button" >Renew Rent</div>
        							            
        							    <?php } ?>
        							<?php } ?>
								</div>	
						</div>
						
					</div>
					<?php } ?>

		        <?php } ?>
			        <div class="pagination"><?php echo $this->pagination->create_links(); ?></div>
				</div>
			</div>
            <div class="allPurposeOverlay">
            	<div class="allPurposeModal">
            			<div class="s_modal_close"><i class="fa fa-times"></i></div>
            		<div class="form-report"></div>
            		<div class="switch-pane">
            			<div class="s_modal_title">Switch Payment Plan</div>
            			<div class="s_modal_note"> 
            				<form id="switch-payment-plan" method="post">
            					<table cellpadding="10" width="100%">
            
            						<tr>
            							<td width="100%">
            								<label style="text-align:left;color:#00CDA6;font-size:14px;">Duration</label>
            								<div class="frequency-spn"></div>
            							</td>							
            						</tr>
            						<tr>
            							<td width="100%">
            								<label style="text-align:left;color:#00CDA6;font-size:14px;">Payment Plan</label>
            								<div class="interval-spn"></div>
            							</td>
            						</tr>
            
            					</table>
            					<input type="submit" class="the-switch-but" value="Switch" />
            				</form>
            			</div>
            		</div>
            		<div class="renew-pane" style="font-family:avenir-regular;font-size:14px;">
            			<div class="s_modal_close"><i class="fa fa-times"></i></div>
            			<div class="s_modal_title">Renew</div>
            			<table width="100%" style="border-collapse:collapse" cellpadding="5px" >
            
            			<tr style="cursor:pointer;" class="pay-option" id="transfer">
            				<td >
            					RentSmallSmall LTD<br />
            
            					Gtbank - 00028388383
            				</td>
            
            				<td>
            					<img src="<?php echo base_url(); ?>assets/images/gtb.png" />
            				</td>
            			</tr>
            			<tr>
            				<td>Or</td>
            				<td></td>
            			</tr>
            			<tr style="cursor:pointer" class="pay-option" id="paystack">
            				<td>Pay Online with Paystack</td>
            				<td>
            					<img src="<?php echo base_url(); ?>assets/images/paystack.png" />
            				</td>
            			</tr>
            		</table>
            		<input type="hidden" id="payment_option" value="" />
            		<div class="continue-but" id="continue-but">Continue</div>
            		</div>
            	
            	</div>
            </div>
    <script>
    	
    </script>
    <script src="<?php echo base_url(); ?>assets/js/user.js"></script>