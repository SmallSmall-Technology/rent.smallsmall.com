	

				<!---- Verification process bar starts--->
						<div class="verification-breadcrumb">
							<div class="verification-breadcrumb-inner">
							    
								<div class="verification-box"><span class="point-cover <?php if(@$verification_status == 'received' || @$verification_status == 'yes' || @$verification_status == 'processing' ){ echo 'colored'; }else{ echo 'uncolored'; } ?>"><i class="fa fa-check-circle-o"></i></span><span class="point-line <?php if(@$verification_status == 'yes' || @$verification_status == 'processing' ){ echo 'colored'; }else{ echo 'uncolored'; } ?>"></span></div>
								<div class="verification-box"><span class="point-cover <?php if(@$verification_status == 'yes' || @$verification_status == 'processing' ){ echo 'colored'; }else{ echo 'uncolored'; } ?>"><i class="fa fa-check-circle-o"></i></span><span class="point-line <?php if(@$verification_status == 'yes' ){ echo 'colored'; }else{ echo 'uncolored'; } ?>"></div>
								<div class="verification-box"><span class="point-cover <?php if(@$verification_status == 'yes'){ echo 'colored'; }else{ echo 'uncolored'; } ?>"><i class="fa fa-check-circle-o"></i></span><span class="point-line <?php if(@$verification_status == 'yes'){ echo 'colored'; }else{ echo 'uncolored'; } ?>"><div class="verification-crumb-icn <?php if(@$verification_status == 'yes'){ echo 'verified-crumb'; }else{ echo 'pending-verification-crumb'; } ?>"></div></div>
								<div class="verification-box-txt">
									<div class="verification-txt">Verification Received</div>	
								</div>
								<div class="verification-box-txt">
									<div class="verification-txt">Verification In Process</div>	
								</div>
								<div class="verification-box-txt">
									<div class="verification-txt">Successfully Verified</div>
									<div class="verification-txt">Start Renting</div>		
								</div>
							</div>
						</div>						
						<!---- Verification process bar ends--->
						
						<!---Main content bar ---->
						<div class="welcome-bar green-tint">
							<div class="welcome-big">Welcome to your dashboard, <?php echo $fname; ?></div>
							<div class="welcome-small">Your dashboard allows you to manage your tenancy with RentSmallSmall for the duration of your stay in our homes.</div>
							<div class="welcome-img">
								<img src="<?php echo base_url(); ?>assets/images/astronaut.png" alt="rentsmallsmall astronaut" />
							</div>
						</div>
						
						
						<div class="user-mainbar-content">
							<div class="welcome-big">What you can do on your dashboard</div>
							<table class="dash-table web-display">
								<tr class="dash-tr">
									<td class="dash-td" valign="middle">
										<span class="wyd-icn smart-phone"></span>
										Pay and renew your rent online securely.
									</td>
									<td class="dash-td">
										<span class="wyd-icn smart-phone"></span>
										See all your transactions and payments with us.
									</td>
								</tr>
								<tr class="dash-tr">
									<td class="dash-td" valign="middle">
										<span class="wyd-icn piggy-bank"></span>
										Save towards your rent by funding your wallet.
									</td>
									<td class="dash-td">
										<span class="wyd-icn piggy-bank"></span>
										Rate and review properties you live in.
									</td>
								</tr>
								<tr class="dash-tr">
									<td class="dash-td" valign="middle">
										<span class="wyd-icn msg-envelope"></span>
										Send and receive messages from our us.
									</td>
									<td class="dash-td">
										<span class="wyd-icn piggy-bank"></span>
										View details about your tenancy.
									</td>
								</tr>
							</table>
							
							<table class="dash-table mobile-display">
								<tr class="dash-tr">
									<td class="dash-td" valign="middle">
										<span class="wyd-icn smart-phone"></span>
										Pay and renew your rent online securely.
									</td>
								</tr>
								<tr class="dash-tr">
									<td class="dash-td">
										<span class="wyd-icn smart-phone"></span>
										See all your transactions and payments with us.
									</td>
								</tr>
								<tr class="dash-tr">
									<td class="dash-td" valign="middle">
										<span class="wyd-icn piggy-bank"></span>
										Save towards your rent by funding your wallet.
									</td>
								</tr>
								<tr class="dash-tr">
									<td class="dash-td">
										<span class="wyd-icn piggy-bank"></span>
										Rate and review properties you live in.
									</td>
								</tr>
								<tr class="dash-tr">
									<td class="dash-td" valign="middle">
										<span class="wyd-icn msg-envelope"></span>
										Send and receive messages from our us.
									</td>
								</tr>
								<tr class="dash-tr">
									<td class="dash-td">
										<span class="wyd-icn piggy-bank"></span>
										View details about your tenancy.
									</td>
								</tr>
							</table>
						</div>
					</div>
					