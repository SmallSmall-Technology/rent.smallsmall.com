                        <div class="user-mainbar-content green-tint">
							
							<div class="wallet-txt text-left">Use our wallet feature to save and pay for your next rent.</div>
							
							<div class="wallet-display">
								<span>
									<div class="wallet-txt-small text-left">Wallet balance</div>
									<div class="wallet-balance text-left"><i style="font-style:normal;font-family:helvetica;font-weight:bold;">&#x20A6;</i><?php echo number_format((float)$wallet_amount['amount'], 2, '.', ''); ?></div>
            						<!--- Paystack form begins here --->
            						<form id="walletForm" autocomplete="no">
            
                            				<!--<input type="hidden" class="email" id="email" value="<?php //echo $email; ?>" required />
                            
                            				<input class="fname" type="hidden" id="fname" value="<?php //echo $fname; ?>" />
                            
                            				<input class="lname" type="hidden" id="lname" value="<?php //echo $lname; ?>" />
                            				
                            				<input class="refID" type="hidden" id="refID" value="<?php //echo "wlt_".md5(date('H:i:s')); ?>" />--->
                
                							<div class="walletTxtCont"><input type="text" class="walletTxt amount" id="amount" placeholder="200000" /></div>
                							
                							<div class="wallet-result"></div>
                							
            								</span>
            							</div>
            							
            						</form>
            						<!--- Paystack form ends here --->
            						<!---Flutterwave form begins here --->
            						<form id="flutterwaveform" action='<?php echo base_url("flutterwave/create_transaction"); ?>' method='post'>
    
                        				<input type='hidden' name='customer_email' value="<?php echo $email; ?>" required/>
                        				
                        				<!---<label>Amount <span class='text-danger'>*</span></label>--->
                        				<input type='hidden' id="cost_amount" name='cost_amount' class='form-control' required/>
                        				
                        				<input type='hidden' name='payment_for' value='wallet' class='form-control'/>
                        				
                        				<input type='hidden' name='payment_plan' value=''  class='form-control'/>
                        				
                        				<!---<label>Currency <span class='text-danger'>*</span></label>--->
                        				<input type='hidden' name='currency' value='NGN' readonly class='form-control'/>
                        				
                        				<input type="hidden" name="referenceID" value="<?php echo "wlt_".md5(date('H:i:s')); ?>" />
                        				
                        				<br><br>
                        				<input type='submit' class='wallet-btn' value='Fund with Flutterwave'/>
                        				<div class="wallet-btn">Pay rent <i class="fa fa-money"></i></div>
                        			</form>
            						<!---Flutterwave form ends here ---->
							
						</div>
					</div>
					<script src="<?php echo base_url(); ?>assets/js/wallet.js"></script>
				<!--- Here is the end ----> 