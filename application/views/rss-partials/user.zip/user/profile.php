                        <div class="user-mainbar-content green-tint">
							<div class="profile-image-container">
								<div class="profile-img">
								    <?php 
        								if($profile['profile_picture']){
        									
        									$link = $profile['userID'].'/'.$profile['profile_picture'];
        										
        								}else{
        									
        									$link = "profile-img.png";
        									
        								}
        							?>
        
        							<img src="<?php echo base_url(); ?>uploads/users/<?php echo $link; ?>" />
								</div>
								<div class="profile-img-change-container button-wrap"> 
        							<label for="userfile" class="new-button"> Upload Picture</label>
        							<input type="file" name="userfile" id="userfile" class="the-profile-pic" /> 
        						</div>
							</div>
							<div class="profile-form-container">
								<form id="updateProfile" method="POST">
									<div class="input-container-user">
										
										<label>Name</label>
											<input type="text" class="userTxt" value="<?php echo $profile['name'] ?>">
									</div>
									<div class="input-container-user col-2">
										<div class="input-medium">
											<label>Email</label>
											<input type="text" class="userTxt email" value="<?php echo $profile['email'] ?>">
										</div>
										<div class="input-medium">
											<label>Phone</label>
											<input type="text" class="userTxt" value="<?php echo $profile['phone'] ?>">
										</div>
									</div>
									<div class="input-container-user col-2">
										<div class="input-medium">
											<label>Income</label>
											<input type="text" class="userTxt income" value="<?php echo $profile['income_level'] ?>">
										</div>
										<div class="input-medium">
											
										</div>
									</div>

									<!---<div class="add-button">Add another <i class="fa fa-plus-circle"></i></div>--->

									<div class="input-container-user col-2">
										<div class="input-medium">
											<label>Password</label>
											<input disabled type="password" class="userTxt password" value="password">
										</div>
										<div class="input-medium">
											<label>Password</label>
											<input disabled type="password" class="userTxt" value="password">
										</div>
										
									</div>
									<input type="hidden" class="user_id" id="user_id" value="<?php echo $profile['userID']; ?>" />
									<button type="submit" class="userBut user-btn">Save</button>
								</form>
							</div>
						</div>
					</div>
<script src="<?php echo base_url(); ?>assets/js/user.js"></script>