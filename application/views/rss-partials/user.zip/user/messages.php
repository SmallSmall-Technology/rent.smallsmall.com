                        <div class="user-mainbar-content">
                            <?php if(isset($messages) && !empty($messages)){ ?>

        						<?php foreach($messages as $message => $item){ ?>
        
        						<?php
        						
        						    $unread_bg = '';
        
        							$CI =& get_instance();
        
        							$admin = $CI->get_admin($item['sender']);
        
        							if($item['status'] == 'unread'){
        							    
        							    $unread_bg = 'unread-background';
        							    
        							}
        
        					   	  ?>
							<div class="dash-table-container">
    							<div class="msg-strip <?php echo $unread_bg; ?>">
    								<div class="msg-inner-items text-left">
    									<img src="<?php echo base_url(); ?>assets/img/logo-rss.png" alt="RSS Logo" />
    								</div>
    								<div class="msg-inner-items">
    									<div class="msg-inner-light text-left">From</div>
    									<div class="msg-inner-heavy text-left"><?php echo $admin['firstName'].' '.$admin['lastName']; ?></div>
    								</div>
    								<div class="msg-inner-items">
    									<div class="msg-inner-light text-left">Date</div>
    									<div class="msg-inner-heavy text-left"><?php echo date('d.m.Y', strtotime($item['dateOfEntry'])); ?></div>
    								</div>
    								<div class="msg-inner-items">
    									<div class="msg-inner-light text-center">Status</div>
    									<div class="msg-inner-heavy text-center"><span class="message-stat <?php echo $item['status']; ?>" id="message-stat-<?php echo $item['id']; ?>"><?php echo ucfirst($item['status']); ?></span></div>
    								</div>
    								<div class="msg-inner-items">
    									<div class="reply-button-o message-button-o unopened open-message" id="message-<?php echo $item['id']; ?>">View <span class="fa fa-angle-down"></span></div>
    								</div>
    								<div class="message-details" id="message-details-<?php echo $item['id']; ?>">
    								    <div class="message-info">
    										<div class="message-title"><?php echo $item['subject']; ?></div> 
    
    										<div class="message-content">
    											
    											<?php echo $item['content']; ?>											
    
    										</div>
    
    										<div class="reply-field" id="reply-field-<?php echo $item['id']; ?>">
    
    											<textarea id="reply-txt-field-<?php echo $item['id']; ?>" class="reply-txt-field" rows="2"></textarea>
    
    											<div class="submit-reply" id="submit-<?php echo $item['id']; ?>">Submit</div>
    
    										</div>
    
    									</div>
    
    									<div class="message-reply-actions">
    
    										<!---<div class="message-date"><?php //echo date('H:ia d.m.Y', strtotime($item['dateOfEntry'])); ?></div>--->
    
    										<!---<div class="reply-button-o" id="message-<?php echo $item['id']; ?>">Reply</div>--->					
    
    									</div>
    
    									<input type="hidden" id="message-id-<?php echo $item['id']; ?>" value="<?php echo $item['requestID']; ?>" />									
    
    									<input type="hidden" id="receiver-id-<?php echo $item['id']; ?>" value="<?php echo $item['sender']; ?>" />
    
    									<input type="hidden" id="subject-<?php echo $item['id']; ?>" value="<?php echo $item['subject']; ?>" />
    
    								</div>
    							</div>
    							
        					        <?php } ?>
        
        					<?php } ?>
    							
    							
    							
    					    </div>	
    					</div>
    				</div>







				<!---<div class="dashboard-mainbar">

							<div class="message-item">

								<div class="message-info">

									<table width="100%" style="font-size:14px">

										<tr>

											<td valign="top" class="m-th">Name</td>

											<td valign="top"  class="m-th">Phone</td>
											
											<td valign="top"  class="m-th">Status</td>

										</tr>

										<tr>

											<td valign="top"  class="m-tc"><b><?php //echo $admin['firstName'].' '.$admin['lastName']; ?></b></td>

											<td valign="top"  class="m-tc"><b><?php //echo $admin['phone']; ?></b></td>
											
											<td valign="top"  class="m-tc">
												<span class="message-stat <?php //echo $item['status']; ?>" id="message-stat-<?php //echo $item['id']; ?>"><?php //echo $item['status']; ?></span>
											</td>

										</tr>

									</table>

								</div>

								<div class="message-actions">

									<div class="message-button-o unopened open-message" id="message-<?php //echo $item['id']; ?>">View message <i class="fa fa-angle-down"></i></div>
									
								</div>

								<div class="message-details" id="message-details-<?php //echo $item['id']; ?>">							

									<div class="message-info">

										<div class="message-title"><?php //echo $item['subject']; ?></div> 

										<div class="message-content">
											
											<?php //print_r($item['content']); ?>											

										</div>

										<div class="reply-field" id="reply-field-<?php //echo $item['id']; ?>">

											<textarea id="reply-txt-field-<?php //echo $item['id']; ?>" class="reply-txt-field" rows="5"></textarea>

											<div class="submit-reply" id="submit-<?php //echo $item['id']; ?>">Submit</div>

										</div>

									</div>

									<div class="message-reply-actions">

										<div class="message-date"><?php //echo date('H:ia d.m.Y', strtotime($item['dateOfEntry'])); ?></div>

										<div class="reply-button-o" id="message-<?php //echo $item['id']; ?>">Reply</div>					

									</div>

									<input type="hidden" id="message-id-<?php //echo $item['id']; ?>" value="<?php //echo $item['requestID']; ?>" />									

									<input type="hidden" id="receiver-id-<?php //echo $item['id']; ?>" value="<?php //echo $item['sender']; ?>" />

									<input type="hidden" id="subject-<?php //echo $item['id']; ?>" value="<?php //echo $item['subject']; ?>" />

								</div>

							</div>


				</div>

			</div>

		</div>

	</div>--->

<script src="<?php echo base_url(); ?>assets/js/message-opener.js" type="text/javascript"></script>