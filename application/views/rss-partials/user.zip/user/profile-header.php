	<div class="dash-user">
		<div class="dash-user-inner">
		    <?php
		        $link = "";
				(@$profile_pic['profile_picture']) ? $link = $userID.'/'.$profile_pic['profile_picture'] : $link = "profile-img.png";
			?>

			<div class="dash-profile-pic">
                <img src="<?php echo base_url(); ?>uploads/users/<?php echo $link; ?>" alt="RSS User picture" />
			</div>
			<div class="dash-profile-name">Hi, <?php echo $fname.' '.$lname ?></div>
		</div>
	</div>
	
	<div class="dash-item-pane">
		<div class="dash-item-pane-inner ">
			
			
			<div class="txt-content">
				<div class="dashboard-sidebar">
					<div class="dash-side-link">
						<a href="<?php echo base_url(); ?>user/dashboard"><span class="side-icn dashboard-icn"></span> <div class="link-name">Dashboard</div></a>
					</div>
					<div class="dash-side-link">
						<a href=""><span class="side-icn favorite-icn"></span> <div class="link-name">Favorites</div></a>
					</div>
					<div class="dash-side-link">
						<a href=""><span class="side-icn rating-icn"></span> <div class="link-name">Property ratings</div></a>
					</div>
					<div class="dash-side-link">
						<a href=""><span class="side-icn notification-icn"></span> <div class="link-name">Notifications</div></a>
					</div>
				</div>
				<div class="dashboard-mainbar">
					<div class="dash-top-pane">
						<div class="dash-top-pane-inner tenant-top-img">
							<div class="desc">Tenant Dashboard</div>
						</div>
						<div class="dash-top-lady"></div>
					</div>
					<div class="dash-main-main">
					    <div class="dash-menu-wrapper">
    						<div class="dash-more-btn left-menu-btn">&laquo;</div>
    						<ul class="dash-menu">
    							<li class="tenant-menu dash-menu-item <?php if($profile_title == 'Profile'){ echo "current-page"; } ?>">
    								<div class="dash-menu-container">
    								    <a class="tenant" href="<?php echo base_url(); ?>user/profile">
        									<div class="dash-icon profile-icn"></div>						
        									<div class="dash-link">Profile</div>
        								</a>
    								</div>
    							</li>
    							<li class="tenant-menu dash-menu-item <?php if($profile_title == 'Bookings'){ echo "current-page"; } ?>" >
    								<div class="dash-menu-container">
    								    <a class="tenant" href="<?php echo base_url(); ?>user/bookings">
        									<div class="dash-icon bookings-icn"></div>						
        									<div class="dash-link">Bookings</div>
    									</a>
    								</div>
    							</li>
    							
    							<li class="tenant-menu dash-menu-item <?php if($profile_title == 'Messages'){ echo "current-page"; } ?>">
    								<div class="dash-menu-container">
    								    <a class="tenant" href="<?php echo base_url(); ?>user/messages">
        									<div class="dash-icon profile messages-icn"></div>	
        									<div class="dash-link">Messages</div>
    									</a>
    								</div>			
    							</li>
    							<li class="tenant-menu dash-menu-item <?php if($profile_title == 'Wallet'){ echo "current-page"; } ?>" >
    								<div class="dash-menu-container">
    								    <a class="tenant" href="<?php echo base_url(); ?>user/wallet">
        									<div class="dash-icon profile wallet-icn"></div>	
        									<div class="dash-link">Wallet</div>
    									</a>
    								</div>						
    							</li>
    							<li class="tenant-menu dash-menu-item <?php if($profile_title == 'Transaction History'){ echo "current-page"; } ?>">
    								<div class="dash-menu-container">
    								    <a class="tenant" href="<?php echo base_url(); ?>user/transactions">
        									<div class="dash-icon profile trans-history-icn"></div>						
        									<div class="dash-link">Transactions</div>
    									</a>
    								</div>
    							</li>
    						</ul>
    						<div class="dash-more-btn right-menu-btn">&raquo;</div>
    					</div>