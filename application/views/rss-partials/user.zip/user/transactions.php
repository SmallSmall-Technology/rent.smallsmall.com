				<div class="user-mainbar-content">
				    <?php if(isset($transactions) && !empty($transactions)){ ?>

						<?php foreach( $transactions as $transaction => $trans ){ ?>

							<?php 

								if(ucfirst($trans['status']) == 'Declined' ){

									$stat = "red";

								}elseif(ucfirst($trans['status']) == 'Pending' ){

									$stat = "grey";

								}elseif(ucfirst($trans['status']) == 'Approved' ){

									$stat = "green";

								}

								//Get user name

							?>
						<div class="txn-strip green-tint">
							<div class="txn-inner-items">
								<div class="msg-inner-light text-left">Transaction amount</div>
								<div class="msg-inner-heavy text-left"><i style="font-style:normal;font-family:helvetica;font-weight:bold;">&#x20A6;</i> <?php echo number_format($trans['amount']); ?></div>
							</div>
							<div class="txn-inner-items">
								<div class="msg-inner-light text-left">Status</div>
								<div class="msg-inner-heavy text-left"><div style="background:<?php echo $stat ?>" class="pass"></div><?php echo $trans['status'] ?></div>
							</div>
							<div class="txn-inner-items">
								<div class="msg-inner-light text-left">Transaction Date</div>
								<div class="msg-inner-heavy text-left"><?php echo date('d.m.Y H:i a', strtotime($trans['transaction_date'])); ?></div>
							</div>
							<div class="txn-inner-items">
								<div class="trans-button-o unopened open-trans" id="trans-<?php echo $trans['id']; ?>">Details <span class="fa fa-angle-down"></span></div>
							</div>
							<div class="trans-details" id="trans-details-<?php echo $trans['id']; ?>">							

    							<div class="trans-info" >
    
    								<div class="trans-dets">Transaction reference: <b style="color:#00CDA4"><?php echo @$trans['reference_id']; ?></b></div>
    
    								<div class="trans-dets">Type of payment: <b style="color:#00CDA4"><?php echo $trans['payment_type']; ?></b></div>
    
    								<div class="trans-dets">Subscription number: <b style="color:#00CDA4"><?php echo $trans['transaction_id']; ?></b></div>
    
    								<div class="trans-dets">Transaction date: <b style="color:#00CDA4"><?php echo date('d.m.Y H:i a', strtotime($trans['transaction_date'])); ?></b></div>
    
    								<!--<div class="trans-dets">Paid by: <b><?php //echo $trans['userID']; ?></b></div>-->
    
    							</div>
    						</div>
						</div>
						<?php } ?>

					<?php } ?>
						
					</div>
				</div>
				
				

<script src="<?php echo base_url(); ?>assets/js/transaction-opener.js" type="text/javascript"></script>