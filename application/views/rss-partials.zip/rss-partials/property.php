<!-- gallery -->
    <?php
        //Multiply the security deposit term by security deposit amount
        $sec_dep = $property['securityDeposit'] * $property['securityDepositTerm'];
    ?>
    <div class="container-fluid gallery">
        <div class="row">
            <div class="col-lg-6 column1">
                <img class="img-fluid" src="<?php echo base_url().'uploads/properties/'.$property['imageFolder'].'/'.$property['featuredImg']; ?>" alt="">
            </div>
            <div class="col-lg-6 column2">
                <?php 
 
					$dir = './uploads/properties/'.$property['imageFolder'].'/';

					if (file_exists($dir) == false) {

						echo 'Directory \'', $dir, '\' not found!'; 

					} else {

						$dir_contents = scandir($dir); 

						$count = 0;
																
						$content_size = count($dir_contents);
						    
						$files = array();

						foreach ($dir_contents as $file) {

							//$file_type = strtolower(end(explode('.', $file)));

							if ( $file !== '.' && $file !== '..'&& $count <= ($content_size - 2) ){ 
							    
							    if($count <= 4){
							        
							        $the_file = base_url().''.$dir.''.$file;
							        
							        array_push($files, $the_file);
							        
							    }

							}  
							$count++;

						}

					}

				?>
                <div class="row">
                    <div class="col-lg-6 column2a"><img src="<?php if(@$files[0]){ echo @$files[0]; }else{ echo base_url('assets/images/no-image.png'); }; ?>" alt=""></div>
                    <div class="col-lg-6 column2b"><img src="<?php if(@$files[1]){ echo @$files[1]; }else{ echo base_url('assets/images/no-image.png'); }; ?>" alt=""></div>
                </div>
                <div class="row">
                    <div class="col-lg-6 column2c"><img src="<?php if(@$files[2]){ echo @$files[2]; }else{ echo base_url('assets/images/no-image.png'); }; ?>" alt=""></div>
                    <div class="col-lg-6 column2d"><img src="<?php if(@$files[3]){ echo @$files[3]; }else{ echo base_url('assets/images/no-image.png'); }; ?>" alt=""></div>
                </div>
            </div>
        </div>

    </div>

    <!-- property -->
    <div class="container property">
        <div class="row property-row">
            <div class="col-lg-8 column1">
                <span class="property-row-heading"><?php echo $property['propertyTitle']; ?></span>
                <span class="verified-prop"><img src="<?php echo base_url(); ?>assets/images/shield-check1.png" alt=""> Verified Property</span>
                <span class="share"> Share <img src="<?php echo base_url(); ?>assets/images/paper-plane2.png" alt=""></span>

                <p class="address"><i class="fa fa-map-pin"></i> <?php echo $property['address'].' '.$property['city'].' '.$property['name']; ?></p>
                <div class="row">
                <div class="col-lg-12">
                    <div class="row specs">
                    <div class="col-lg-2 spec"><img src="<?php echo base_url(); ?>assets/images/single-bed1.png" alt=""><?php echo $property['bed']; ?> Bedroom</div>
                    <div class="col-lg-2 spec"><img src="<?php echo base_url(); ?>assets/images/bathtub(2).png" alt=""><?php echo $property['bath']; ?> Bathroom</div>
                    <div class="col-lg-2 spec"><img src="<?php echo base_url(); ?>assets/images/toilet.png" alt=""><?php echo $property['toilet']; ?> Toilet</div>
                    <?php if($property['furnishing'] == 2){ ?>
                        <div class="col-lg-2 spec"><img src="<?php echo base_url(); ?>assets/images/sofa(1)-1.png" alt="">Furnishing</div>
                    <?php } ?>
                    <div class="col-lg-2 spec"><img src="<?php echo base_url(); ?>assets/images/Frame.svg" alt="">Gen</div>
                    </div>
                </div>
                </div>
                <p class="m-by">Managed by <strong><?php echo $property['manager']; ?></strong> </p>

                                <!-- about -->
                <div class="row about">
                
                    <p class="about-heading">About this property</p>
                    <p class="about-text">
                        <?php echo nl2br(html_entity_decode($property['propertyDescription'])); ?>
                    </p>
                 
                </div>

             <!-- amenities -->
            <div class="row amenities">
            <div class="col-lg-8">
                <p class="amenities-heading">Amenities</p>
                <div class="row">
                <div class="col-lg-4">
                     <?php 

						$amenity = unserialize($property['amenities']);

						$amenity_list = "";

					?>
					<?php $amenity_count = count($amenity); ?>
					<?php if(in_array('prepaid',$amenity)){ ?>
                         <div class="amenities-spec">
                             <span><img src="<?php echo base_url(); ?>assets/images/power-meter.png" alt=""></span>
                             <span>Prepaid meter</span>
                         </div>
                     <?php } ?>
                     <?php if(in_array('water',$amenity)){ ?>
                         <div class="amenities-spec">
                             <span><img src="<?php echo base_url(); ?>assets/images/water-faucet1.png" alt=""></span>
                             <span>Water</span>
                         </div>
                     <?php } ?>
                     <?php if(in_array('security-gate',$amenity)){ ?>
                         <div class="amenities-spec">
                             <span><img src="<?php echo base_url(); ?>assets/images/police1.png" alt=""></span>
                             <span>Security</span>
                         </div>
                     <?php } ?>
                     <?php if(in_array('water-disposal',$amenity)){ ?>
                         <div class="amenities-spec">
                             <span><img src="<?php echo base_url(); ?>assets/images/truck1.png" alt=""></span>
                             <span>Water disposal</span>
                         </div>
                     <?php } ?>
                 </div>
                 <div class="col-lg-4">
                     <?php if(in_array('kitchen',$amenity)){ ?>
                         <div class="amenities-spec">
                             <span><img src="<?php echo base_url(); ?>assets/images/kitchen-table1.png" alt=""></span>
                             <span>Kitchen</span>
                         </div>
                     <?php } ?>
                     <?php if(in_array('wardrobe',$amenity)){ ?>
                         <div class="amenities-spec">
                             <span><img src="<?php echo base_url(); ?>assets/images/wardrobe1.png" alt=""></span>
                             <span>Wardrobe</span>
                         </div>
                     <?php } ?>
                     <?php if(in_array('dining',$amenity)){ ?>
                         <div class="amenities-spec">
                             <span><img src="<?php echo base_url(); ?>assets/images/chairs1.png" alt=""></span>
                             <span>Dinning</span>
                         </div>
                     <?php } ?>
                     <?php if(in_array('air-condition',$amenity)){ ?>
                         <div class="amenities-spec">
                             <span><img src="<?php echo base_url(); ?>assets/images/air-conditioner1.png" alt=""></span>
                             <span>Ac</span>
                         </div>
                     <?php } ?>
                 </div>
                 <div class="col-lg-4">
                    <?php if(in_array('security-gate',$amenity)){ ?>
                        <div class="amenities-spec">
                             <span><img src="<?php echo base_url(); ?>assets/images/Frame.svg" alt=""></span>
                             <span>Gen</span>
                        </div>
                    <?php } ?>
                 </div>
             </div>
         </div>
         </div>

         <!-- house-rules -->
         <div class="house-rules">
             <p class="hr-heading">House rules</p>
             <p class="hr-text">House rules violation may result in a subscription fine</p>
             <p><img src="<?php echo base_url(); ?>assets/images/check(4)-1.png" alt=""> No smoking</p>
             <p><img src="<?php echo base_url(); ?>assets/images/check(4)-1.png" alt=""> No pets</p>       
         </div>

         <!-- neighbourhood -->
         <div class="row neighbourhood">
         <div class="col-lg-12">
            <p class="n-heading">Neighbourhood </p>

            <div class="card-group">
                <?php

					$CI =& get_instance();

					$facilities = $CI->get_facilities($property['propertyID']);
					
					foreach($facilities as $facility => $outlet){

				?>
				    <div class="n-card neighborhood-item">
				        <div class="neighborhood-img">
                            <img src="<?php echo base_url()."uploads/properties/".$property['imageFolder'].'/facilities/'.$outlet['file_path']; ?>" class="card-img-top" alt="...">
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $outlet['name']; ?></h5>
                            <p class="card-text"><?php echo $outlet['category']; ?></p>
                            <p class="card-text"><?php echo $outlet['distance']; ?></p>
                        </div>
                    </div>
					
				<?php } ?>
                 
               </div>

            </div>
        </div>

            </div>
            <!-- /column1 -->

            <!-- subscription price -->
            <div class="col-lg-4 column2">
                <p class="price-heading">Subscription Price</p>
                <p class="price-tag-heading"><span style="font-family:helvetica;">&#x20A6;</span><?php echo number_format($property['price']); ?>/month</p>
                <p>
                    <span class="p-text">Security deposit</span>
                    <span class="p-price"><span style="font-family:helvetica;">&#x20A6;</span><?php echo number_format($sec_dep); ?></span>
                </p>

                <div id="inspect" class="switch">
					<label class="switch-btn inspection" onclick="">
							<input name="action-type" type="checkbox">
							<span>
								<span id="act-inspect" class="subscribe-btn whiten">Schedule a visit</span>
								<span id="act-subscribe" class="sub-s-btn">Subscribe now</span>
							</span>
							<a class="btn btn-primary"></a>
					</label>
				</div>

                    <!---- Inspection form ---->
                    <div class="inspection-form">
                        <p class="visit">Choose visit type and date</p>
                        <form id="inspectionForm" method="post">
                            <div class="form-container-box">
                                <label for="move-in-date">Inspection type</label>
                                <select class="form-select insp-type" id="customSelect" name="">
                                    <option value="physical">Physical</option>
                                    <option value="virtual">Virtual</option>
                                </select>
                            </div>
                            <div class="form-container-box" style="position:relative">
                                <label for="inspection-date">Inspection date</label>
                                <!---<input name="inspection-date" id="field-date" autocomplete="off" class="book-inspection-field date-txt-fld" placeholder="dd/mm/yyyy" />--->
                                <input type="date" name="inspection-date" id="field-date" autocomplete="off" class="book-inspection-field date-txt-fld" placeholder="dd/mm/yyyy" />
                                <span class="bx bx-calendar move-in-date-cal"></span>
                            </div>
                            <div class="form-container-box" style="position:relative">
                                <label for="inspection-date">Inspection time</label>
                                <input autocomplete="off" type="text" id="input" list="inspection-time"  name="inspection-time" autocomplete="off" class="inspection-time date-txt-fld" placeholder="Pick a time" />
                                <datalist role="listbox" id="inspection-time">
                                    <option value="8:00">8:00 AM</option>
                                    <option value="8:30">8:30 AM</option>
                                    <option value="9:00">9:00 AM</option>
                                    <option value="9:30">9:30 AM</option>
                                    <option value="10:00">10:00 AM</option>
                                    <option value="10:30">10:30 AM</option>
                                    <option value="11:00">11:00 AM</option>
                                    <option value="11:30">11:30 AM</option>
                                    <option value="12:00">12:00 PM</option>
                                    <option value="12:30">12:30 PM</option>
                                    <option value="13:00">1:00 PM</option>
                                    <option value="13:30">1:30 PM</option>
                                    <option value="14:00">2:00 PM</option>
                                    <option value="14:30">2:30 PM</option>
                                    <option value="15:00">3:00 PM</option>
                                    <option value="15:30">3:30 PM</option>
                                    <option value="16:00">4:00 PM</option>
                                    <option value="16:30">4:30 PM</option>
                                    <option value="17:00">5:00 PM</option>
                                    <option value="17:30">5:30 PM</option>
                                    <option value="18:00">6:00 PM</option>
                                    <option value="18:30">6:30 PM</option>
                                </datalist>
                                <span class="bx bx-alarm move-in-date-cal"></span>
                            </div>
                            <div class="form-group">
                                <input name="tenancy-terms" class="form-check-input" type="checkbox" value="" id="tenancy-terms" required>
                                <label class="form-check-label" for="invalidCheck">
                                    Agree to <a href="<?php echo base_url('terms-of-use'); ?>">Subscription terms</a> 
                                  </label>
                            </div>
                            <?php if($property['available_date'] <= date('Y-m-d H:is') || $property['available_date'] == '') { ?>

							
							    <?php if(@$user_type == 'landlord'){ ?>
							    
							            <button disabled class="form-control" type="button">Book inspection</button>
							    
							    <?php }else{ ?>
							    
							            <button class="form-control schedule-inspection" type="submit">Book inspection</button>
							    
							    <?php } ?>
							    
						    <?php }else{ ?>
                                    <?php if($property['available_date'] == date('Y-m-d', strtotime('+ 1 day'))) { ?>
                                            <button class="form-control" disabled type="button">Available in 24hrs</button>
                                    <?php }else{ ?>
                                    
        							    <button class="form-control" disabled type="button">Unavailable</button>
        							
        							<?php } ?>
        
        					<?php } ?>
                            
                        </form>
                    </div>
                    <!----Inspection form ----->
                    
                    <!--- Subscription form --->
                    <div class="subscription-form">
                        <p class="visit">Book a subscription</p>
                        <form id="paymentForm" method="post">
                            <!---<label for="form2">Subscribe</label>--->
                            <?php
    
    							$duration = "";
    
    							$fullduration = 0;
    
    							$frequency = unserialize($property['frequency']);
    							if(is_array($frequency)){
    
    								for($i = 0; $i < count($frequency); $i++){
    
    									if($frequency[$i] == 12){
    
    										$duration .= '<option value="'.$frequency[$i].'"> 12 Months </option>';
    
    										$fullduration = 1;
    
    									}elseif($frequency[$i] == 9){
    
    										$duration .= '<option value="'.$frequency[$i].'"> 9 Months </option>';
    
    									}elseif($frequency[$i] == 6){
    
    										$duration .= '<option value="'.$frequency[$i].'"> 6 Months </option>';
    
    									}elseif($frequency[$i] == 3){
    
    										$duration .= '<option value="'.$frequency[$i].'"> 3 Months </option>';
    
    									}elseif($frequency[$i] == 1){
    
    										$duration .= '<option value="'.$frequency[$i].'"> 1 Month </option>';
    
    									}
    
    								}
    							}else{
    							    $duration .= '<option value="1"> 1 Month </option>';
    							}
    
    						?>
                            <div class="form-container-box">
                                <label>Duration</label>
                                <select class="customSelect duration" id="duration" name="duration">
                                    <?php echo $duration; ?>
                                </select>
                            </div>
                            <div class="form-container-box">
                                <label>Payment plan</label>
                                <select class="customSelect payment_plan" id="payment-plan" name="payment-plan">
                                    <?php
        
        								$intervals = "";
        
        								$interval = unserialize($property['intervals']);
        
        								for($i = 0; $i < count($interval); $i++){
        
        									echo '<option value="'.$interval[$i].'">'.$interval[$i].'</option>';
        
        								}
        
        							?>
                                </select>
                            </div>
                            <div class="form-container-box" style="position:relative">
                                <label for="move-in-date">Move in date</label>
                                <input style="border:1px solid #333" class="move-in-date book-inspection-field date-txt-fld" type="date" name="move-in-date" id="move-in-date" />
                                <span class="bx bx-calendar move-in-date-cal"></span>
                            </div>
                            <div class="form-container-box">
                                <label>Book as</label>
    
    							<select name="book-as" class="book-as customSelect" id="book-as">
    
    							  <option value="Individual" selected="selected">Individual</option>
    
    							  <option value="Corporate">Corporate</option>
    
    							</select>
                            </div>
                            
                            <table class="pay-table" width="100%">
                                <tr>
                                    <td width="60%"><span class="td-desc">Subscription fees</span></td>
                                    <td><span class="td-note"><span style="font-family:helvetica;">&#x20A6;</span><?php echo number_format($property['price']); ?></span></td>
                                </tr>
                                <tr>
                                    <td><span class="td-desc">Security Deposit</span></td>
                                    <td><span class="td-note"><span style="font-family:helvetica;">&#x20A6;</span><?php echo number_format($sec_dep); ?></span></td>
                                </tr>
                                <tr>
                                    <td><span class="td-desc">Total Pay</span></td>
                                    <td><span class="td-note"><span style="font-family:helvetica;">&#x20A6;</span><span id="pricing"><?php echo number_format($sec_dep + $property['price']); ?></span></span></td>
                                </tr>
                            </table>
                            
                            <?php if($property['available_date'] <= date('Y-m-d H:is') || $property['available_date'] == '') { ?>

							
							    <?php if(@$user_type == 'landlord'){ ?>
							    
							            <button disabled class="form-control" disabled type="submit">Subscribe</button>
							    
							    <?php }else{ ?>
							    
							            <button class="form-control" id="pay-property" type="submit">Subscribe</button>
							    
							    <?php } ?>
							    
						    <?php }else{ ?>
                                    <?php if($property['available_date'] == date('Y-m-d', strtotime('+ 1 day'))) { ?>
                                            <button class="form-control" disabled type="submit">Available in 24hrs</button>
                                    <?php }else{ ?>
                                    
        							    <button class="form-control" disabled type="submit">Unavailable</button>
        							
        							<?php } ?>
        
        					<?php } ?>
                            
                            
                            <div class="form-group">
                                <p>
                                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                                    <label class="form-check-label" for="invalidCheck">Agree to <a href="<?php echo base_url('terms-of-use'); ?>">Subscription terms</a></label>
                                </p>
                            </div>
                            <!---<div class="form-group">
                                <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                                <label class="form-check-label" for="invalidCheck">
                                    Agree to <a href="">Subscription terms</a> 
                                  </label>
                            </div>--->
    
                            
                        </form>
                    </div>
                    <!---Subscription form ---->
            </div>
        </div>
    </div>
    <input type="hidden" class="userID" id="userID" value="<?php echo @$userID; ?>" />
				
		<input type="hidden" class="verified" id="verified" value="<?php echo @$verified; ?>" />

		<input type="hidden" class="productName" id="productName" value="<?php echo $property['propertyTitle']; ?>" />

		<input type="hidden" class="property-id" id="property_id" value="<?php echo $property['propertyID']; ?>" />

		<input type="hidden" class="prop-monthly-price" id="monthly-price" value="<?php echo $property['price'] ?>" />

		<input type="hidden" class="sec-deposit" id="sec-deposit" value="<?php echo $sec_dep; ?>" />

		<input type="hidden" class="serv-charge" id="serv-charge" value="<?php echo $property['serviceCharge']; ?>" />
		
		<input type="hidden" class="cvstat" id="cvstat" value="<?php echo @$verified; ?>" />
		
		<input type="hidden" class="verification_profile" id="verification_profile" value="<?php echo @$verification_profile; ?>" />
		<?php 
		    $inspection_stat = "no";
		    if(@$check_inspection){
		        $inspection_stat = "yes";
		    }
		?>
		<input type="hidden" class="inspection_stat" id="inspection_stat" value="<?php echo @$inspection_stat ?>" />
		<input type="hidden" class="apt-type" id="apt-type" value="<?php echo @$property['type_slug']; ?>" />

		<input type="hidden" class="imageLink" id="imageLink" value="<?php echo base_url().'uploads/properties/'.$property['imageFolder'].'/'.$property['featuredImg']; ?>" />

		<input type="hidden" class="amount-due" id="amount-due" value="<?php echo $property['price'] + $sec_dep; ?>" />
    
    <!-- properties nearby -->
    <div class="container nearby">
        <p class="nearby-heading">Similar properties nearby</p>
        <div class="row">
            <?php if(isset($relatedProps)){ ?>
    
    			<?php foreach($relatedProps as $relatedProp => $related){ ?>
                <div class="col-lg-4 n-card">
                    <a href="<?php echo base_url(); ?>property/<?php echo $related['propertyID']; ?>">
                        <div class="prop-img-container">
                            <img src="<?php echo base_url(); ?>uploads/properties/<?php echo $related['imageFolder']."/".$related['featuredImg'] ?>" class="card-img-top" alt="...">
                            <?php
    							$CI =& get_instance();
    												  
    							//@$avail_date = $CI->get_available_date($value['propertyID']);
    
    							if(date('Y-m-d') <= $related['available_date']){
    
    								echo '<p class="img-tag">Rented Until - <span class="occupied">'.date("M Y", strtotime($related['available_date'])).'</span></p>';
    
    							}else{
    								
    								echo '<p class="img-tag">Available - <span>now</span></p>';
    							}
    
    						?>
    				    </div>
                        <div class="card-body">
                            <p class="card-title">
                                <span><span style="font-family:helvetica;">&#x20A6;</span><?php echo number_format($related['price']); ?>/Month</span>
                                <span><strike><span style="font-family:helvetica;">&#x20A6;</span><?php echo number_format($related['price'] * 12); ?>/Year</strike></span>
                            </p>
                            <p class="card-text"><?php echo $related['address'].", ".$related['city'] ; ?></p>
                            <p class="card-text">
                                &bullet;
                                <span><?php echo $related['bed']; ?> Bed</span>
                                &bullet;
                                <span><?php echo $related['bath']; ?> Bath</span>
                                &bullet;
                                <span>Lagos</span>
                            </p>
                        </div>
                    </a>
                </div>
                <?php } ?>
            <?php } ?>
                
             
        </div>
    </div>
</div>
    <!--<script>
        $(function () {
            var today = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
            
            var dayOfTheWeek = new Date().getDay();
            
            var disabledDays = [0, 1];
            
            if(dayOfTheWeek == 6 || dayOfTheWeek == 0){
                
                disabledDays = [0, 1, 6];
                
            }
            
            $('#field-date').datetimepicker({ 
                format: 'DD-MM-YYYY HH:mm',
                defaultDate: today,
                minDate: today,
                daysOfWeekDisabled: disabledDays,
                disabledDates: [
                    moment("03/29/2021"), "03/30/2021 00:53"
                ]
            });
            
        });
    </script>--->
    <script src="<?php echo base_url(); ?>assets/js/image-swap.js"></script>

    <script language="JavaScript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/inspection.js?version=9.10.2"></script>
    
    <script src="<?php echo base_url(); ?>assets/js/payment-plan.js"></script>
    
    <script src="<?php echo base_url(); ?>assets/js/rent-calculator.js"></script>
    
    <script src="<?php echo base_url(); ?>assets/js/rental.js"></script>
    
    <script src="<?php echo base_url(); ?>assets/js/thumbnail-scroller.js"></script>
    
    <script src="<?php echo base_url(); ?>assets/js/favorite.js"></script>