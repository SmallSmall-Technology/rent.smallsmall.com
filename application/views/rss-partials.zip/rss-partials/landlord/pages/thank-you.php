<div class="pane-banner">
		<div class="banner-title">
			Add Your Property<br />
			<span class="small-banner-title">Rent your property to verified tenants</span>
		</div>
	</div>
	<div class="item-pane">
		<div class="pane-inner">
			<h1>Thank you!</h1>
			<h5>Your property is awaiting approval, we aill contact you as soon as possible.</h5>
		</div>
	</div>
