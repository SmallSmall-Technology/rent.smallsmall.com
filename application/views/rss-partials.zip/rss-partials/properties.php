	<!-- info -->
    <div class="container-fluid info property-search-container">
        <div class="row property-search-row">
            <div class="col-lg-2 col-md-2 dropdown">
                <a class="active" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" href="#">
                <p>City</p>
                <span><img src="<?php echo base_url(); ?>assets/images/location-1.png" alt=""></span>
                <span>Any</span></a>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item heading" href="#">City</a></li>
                    <li><a class="dropdown-item" href="#">Lagos</a></li>
                    <li><a class="dropdown-item" href="#">Abuja</a></li>
                    <li><a class="dropdown-item" href="#">Enugu</a></li>
                    <li><a class="dropdown-item" href="#">Accra</a></li>
                    <li><a class="dropdown-item" href="#">Nairobi</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-2 dropdown">
                <a class="active" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" href="#">
                <p>Locations</p>
                <span><img src="<?php echo base_url(); ?>assets/images/adress-1.png" alt=""></span>
                <span>Any</span></a>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item heading" href="#">Location</a></li>
                    <li><a class="dropdown-item" href="#">Lekki Phase 1</a></li>
                    <li><a class="dropdown-item" href="#">Ikoyi</a></li>
                    <li><a class="dropdown-item" href="#">Ajah</a></li>
                    <li><a class="dropdown-item" href="#">Agungi</a></li>
                    <li><a class="dropdown-item" href="#">Sangotedo</a></li>
                    <li><a class="dropdown-item" href="#">Ikota</a></li>
                    <li><a class="dropdown-item" href="#">Yaba</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-2 dropdown">
                <a class="active" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" href="#">
                <p>Bedrooms</p>
                <span><img src="<?php echo base_url(); ?>assets/images/bed-12.png" alt=""></span>
                <span>Any</span></a>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item heading" href="#">Bedroom</a></li>
                    <nav aria-label="...">
                        <ul class="pagination">
                          <li class="page-item disabled">
                            <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Studio</a>
                          </li>
                          <li class="page-item active" aria-current="page">
                            <a class="page-link" href="#">1</a>
                          </li>
                          <li class="page-item"><a class="page-link" href="#">2</a></li>
                          <li class="page-item"><a class="page-link" href="#">3</a></li>
                          <li class="page-item">
                            <a class="page-link" href="#">4+</a>
                          </li>
                        </ul>
                      </nav>
                </ul>
            </div>
            <div class="col-lg-2 col-md-2 dropdown">
                <a class="active" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" href="#">
                <p>Price</p>
                <span><img src="<?php echo base_url(); ?>assets/images/price-tag-1.png" alt=""></span>
                <span>N0 - N5m </span></a>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item heading" href="#">Price range</a></li>
                    <li><a class="dropdown-item" href="#">Upcoming homes</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-2 dropdown">
                <a class="active" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" href="#">
                <p>Furnishing</p>
                <span><img src="<?php echo base_url(); ?>assets/images/cabinet(1)-1.png" alt=""></span>
                <span>Any</span></a>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item heading" href="#">Furnishing</a></li>
                    <li><a class="dropdown-item" href="#">Furnished</a></li>
                    <li><a class="dropdown-item" href="#">Partially furnished</a></li>
                    <li><a class="dropdown-item" href="#">Unfurnished</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-2 dropdown">
                <a class="active" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" href="#">
                <p>Availability</p>
                <span><img src="<?php echo base_url(); ?>assets/images/calendar1.png" alt=""></span>
                <span>Any</span></a>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item heading" href="#">Availability</a></li>
                   
                    <li><a class="dropdown-item" href="#"> <select class="form-control form-select" name="" id="">
                        <option value="1 month">1 month</option>
                    </select></a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- gallery -->
    <div class="container-fluid nearby">

        <div class="row">
            <?php if(isset($properties) && !empty($properties)){ ?>

				<?php foreach($properties as $property => $value){ ?>
                    <div class="col-lg-4 n-card">
                        <div class="prop-img-container">
                            <img src="<?php echo base_url(); ?>uploads/properties/<?php echo $value['imageFolder']."/".$value['featuredImg'] ?>" class="card-img-top" alt="...">
                            <?php
    							$CI =& get_instance();
    
    							if(date('Y-m-d') <= $value['available_date']){
    
    								echo '<p class="img-tag">Rented Until - <span class="occupied">'.date("M Y", strtotime($value['available_date'])).'</span></p>';
    
    							}else{
    								
    								echo '<p class="img-tag">Available - <span>now</span></p>';
    							}
    
    						?>
                        </div>
                        
                        
                        <a href="<?php echo base_url(); ?>property/<?php echo $value['propertyID']; ?>">
                            <div class="card-body">
                                <p class="card-title">
                                    <span><span style="font-family:helvetica;">&#x20A6;</span><?php echo number_format($value['price']); ?>/Month</span>
                                    <span><strike><span style="font-family:helvetica;">&#x20A6;</span><?php echo number_format($value['price'] * 12); ?>/Year</strike></span>
                                </p>
                                <p class="card-text"><?php echo $value['address'].", ".$value['city'] ; ?></p>
                                <p class="card-text">
                                    &bullet;
                                    <span><?php echo $value['bed']; ?> Bed</span>
                                    &bullet;
                                    <span><?php echo $value['bath']; ?> Bath</span>
                                    &bullet;
                                    <span>Lagos</span>
                                </p>
                          </div>
                        </a>
                    </div>
                
                    <?php } ?>
							
			    <?php } ?>
                
                <div class="pagination">
    				<?php echo $this->pagination->create_links(); ?>
    			</div>
			</div>
        </div>
    </div>
    </div>
<script src="<?php echo base_url(); ?>assets/js/inspection.js"></script>
<script src="<?php echo base_url(); ?>assets/js/property-sort-pane.js"></script>
<script>
	var slider = document.getElementById("myRange");
	var output = document.getElementById("slidevalue");
	output.innerHTML = numberWithCommas(slider.value+"/mth"); // Display the default slider value

	// Update the current slider value (each time you drag the slider handle)
	slider.oninput = function() {
	  	output.innerHTML = numberWithCommas(this.value+"/mth");
	}
	
	function numberWithCommas(x) {
		return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	}
</script>
<!---<script>
    mapboxgl.accessToken = 'pk.eyJ1IjoicmVudHNtYWxsc21hbGwiLCJhIjoiY2tkZ2I3ajNtMHFrYjJyb2JoMWNjNWllMSJ9.Ba7Iw2TAhxBPuTcLdQWDzQ';
    var map = new mapboxgl.Map({
        container: 'map',
        center: [2.883430,6.416970], // starting position
        style: 'mapbox://styles/mapbox/streets-v11',
        zoom: 9
    });
    // Set options
    var marker = new mapboxgl.Marker({
        color: "#00CDA4",
        draggable: true
      }).setLngLat([2.883430,6.416970]).addTo(map);
      
</script>--->