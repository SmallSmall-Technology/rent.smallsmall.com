    <div class="verification-form">
        <div class="details">
            <h1>Renting history</h1>
            <p class="beforeyou">Before you can subscribe with us we need to know who you are since this will be a long partnership. We do not share data with any 3rd party or government agency.</p>
            <p>2 of 5</p>
        </div>
        <div class="progress" style="height: 9px; width: 100%;">
            <div class="progress-bar" role="progressbar" style="width: 40%; background: #007DC1 !important;" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <div class="form">
            <form id="rentingHistoryForm" autocomplete="off" class="verificationForm regForm" method="POST">
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control present_address verify-txt-f" placeholder="Address">
                    </div>
                    <div class="col">
                        <select name="country" class="customSelect country verify-txt-f" >

							  <option value="" selected="selected">Country</option>

							   <?php

									$CI =& get_instance();

									$countries = $CI->get_countries();

									foreach($countries as $country => $value){

										echo '<option value="'.$value['id'].'">'.$value['name'].'</option>';

									}

							   ?>

							</select>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <select name="states" class="customSelect verify-txt-f states" id="states">

							<option value="">State</option>

						</select>
                    </div>
                    <div class="col">
                        <input type="text" class="form-control verify-txt-f" disabled id="city" placeholder="City/Town">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <select name="previous-rent" class="customSelect previous_rent_duration" id="previous-rent">

							  <option value="" selected="selected">Previous rent duration</option>

							  <option value="1" >1 Year</option>

							  <option value="2" >2 Years</option>

							  <option value="3" >3 Year</option>

							  <option value="4" >4 Year</option>

							  <option value="5" >5 Year</option>

							  <option value="6" >6 Year</option>

							  <option value="7" >7 Year</option>

							  <option value="8" >8 Year</option>

							  <option value="9" >9 Year</option>

							  <option value="10">10 Year</option>

						</select>
                    </div>
                    <div class="col">
                        <select name="search_categories" class="customSelect renting_status" id="soflow">

						    <option value="" selected="selected">Current renting status</option>

						    <option value="Yes">Renting</option>

						    <option value="No">Not Renting</option>

						</select>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <select name="previous-eviction" class="customSelect previous_eviction">

						    <option value="" selected="selected">Previous Evictions?</option>

						    <option value="Yes">Yes</option>

						    <option value="No">No</option>

						</select>
                    </div>
                    <div class="col">
                        <select name="pet" class="customSelect pet" id="pet">

						    <option value="" selected="selected">Pets</option>

						    <option value="Yes">Yes</option>

						    <option value="No">No</option>

						</select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col">
                        <select name="critical-illness" class="customSelect critical_illness" id="">

						  <option value="" selected="selected">Disability/Illness?</option>

						  <option value="Yes">Yes</option>

						  <option value="No" >No</option>

						</select>
                    </div>
                    <div class="col">
                        <input type="text" id="landlord_full_name" class="form-control landlord_full_name verify-txt-f" placeholder="Landlord's Full name">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control landlord_email" placeholder="Landlord Email">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control landlord_phone verify-txt-f" placeholder="Landlord Telephone">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <textarea class="form-control landlord_address verify-txt-f" rows="5" placeholder="Address"></textarea>
                    </div>
                    <div class="col">
                        <textarea class="form-control reason_for_leaving" rows="5" placeholder="Reason for leaving previous address"></textarea>
                    </div>
                </div>
                <button type="submit" id="verifyBut" class="btn btn-primary rentingBut verifyBut" style="width: 308px;">Next</button>
            </form>
        </div>
        
          
    </div>
<script src="<?php echo base_url().'assets/js/verification.js' ?>"></script>

<script src="<?php echo base_url().'assets/js/country-picker.js' ?>"></script>