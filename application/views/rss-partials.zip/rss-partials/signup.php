    <div class="container login-container">
      <img src="<?php //echo base_url(); ?>assets/front/images/login-image.png" alt="">
      <div class="row login-mobile-top">
        <div class="col mobile-logo"><img src="<?php //echo base_url(); ?>assets/front/images/mobile-logo.png" alt=""></div>
        <div class="col"><button type="submit"  name="login" class="create-account-mobile-btn">Create Account</button></div>
      </div>
      
        <div class="row login-row">
            <div class="col-lg-4 col-md-4 col-sm-12 form-section">
                <p class="login-header">Let your joy begin</p>
                <p class="login-title"> Create your account </p>

                <div class="signup-space">
                    
                    <p>1 of 3</p>
                </div>
                <div class="progress" style="height: 9px; margin-bottom: 50px;">
                    <div class="progress-bar" role="progressbar" style="width: 25%; background: #007DC1 !important;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <div class="form">
                    
                    <form id="regForm" method="post">
                                                
                        <div style="padding:5px;border-radius:4px;" class="form-report"></div>

                        <fieldset>
                            <input class="form-control reg-fields" id="fname" type="text" name="firstName" placeholder="First name">
    
                            <input class="form-control reg-fields" id="lname" type="text" name="lastName" placeholder="Last name">
    
                            <input class="form-control reg-fields" id="email" type="email" name="email" placeholder="Email address">
                       
                            <input class="form-control reg-fields" id="phone" type="phone" name="phoneNumber" placeholder="Phone number">
    
                            <button type="button"  name="next" class="next next-classic-btn">Next</button>
    
                        </fieldset>

                        <fieldset>

                            <div class="input-group">
                                <input class="form-control form-password reg-fields" id="password" type="password" name="password" placeholder="Password">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <a href="#" class="toggle_hide_password">
                                            <i class="fas fa-eye-slash" aria-hidden="true"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
    
                            <div class="input-group">
                                <input class="form-control form-password reg-fields" id="password_2" type="password" name="confirm-password" placeholder="Confirm password">   
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <a href="#" class="toggle_hide_password">
                                            <i class="fas fa-eye-slash" aria-hidden="true"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
    
                            <input class="form-control reg-fields" type="number" id="age" name="age" placeholder="Age">
                       
                            <input class="form-control income reg-fields" id="income" type="text" name="income" placeholder="Monthly income">
    
                            <button type="button"  name="next" class="previous previous-btn">Back</button>
                            <button type="button"  name="next" class="next next-btn">Next</button>
                        </fieldset>

                        <fieldset>
                            <select class="form-control form-select gender reg-fields" id="gender" name="gender">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
    
                            <select id="referral" class="form-control form-select referral reg-fields">
                                <option selected>How did you hear about us</option>
                                <option value="Television" selected >TV</option>
    							<option value="Radio" >Radio</option>
    							<option value="Instagram" >Instagram</option>
    							<option value="Twitter" >Twitter</option>
    							<option value="Facebook" >Facebook</option>
    							<option value="WOM" >Word of Mouth</option>
                            </select>
        
                            <input class="form-control" id="referral_code" type="text" name="" placeholder="Referral code ( optional )">
                            
                            <select id="interest" class="form-control form-select interest reg-fields">
                                <option selected value="">What is your interest?</option>
                                <option value="RSS">Renting a home</option>
                                <option value="Buy2let">Buying a home</option>
                                <option value="Stayone">Short stays</option>
                            </select>
                            
                            <input type="hidden" id="clicked" val="0" />
        
                            <p class="agree">By signing up, you agree to our <a href="<?php //echo base_url('terms-of-use'); ?>">Terms of service</a> and <a href="<?php echo base_url('privacy-policy'); ?>">Privacy Policy</a> </p>
                                <button type="button"  name="next" class="previous previous-btn">Back</button>
                                <button type="submit"  name="" class="finish-btn next-btn">Finish</button>
                                
                        </fieldset>
                        
                    </form>
                    
                </div>
            </div>

        <div class="col-lg-4 offset-lg-4 col-md-4 offset-md-4 col-sm-12 login-background">
            <img src="images/RSS-H-1.png" class="login-logo" alt="">
             
            
            <p class="create-p">Have an account? <a href="<?php //echo base_url('login'); ?>">Sign In</a></p>
            <p class="text-p">Download the App</p>

            <div class="button">
              <button type="button" class="btn btn-dark btn-lg"><i class="fab fa-apple"></i> on the App store </button>
              <button type="button" class="btn btn-outline-dark btn-lg"><i class="fab fa-google-play"></i> on Google play </button>

            </div>
        </div>  

       
    </div>

</div>
<!---<div class="container login-container">
    <img src="<?php //echo base_url(); ?>assets/front/images/login-image.png" alt="">
    <div class="row login-mobile-top">
        <div class="col mobile-logo"><img src="<?php //echo base_url(); ?>assets/front/images/mobile-logo.png" alt=""></div>
        <div class="col"><button type="submit"  name="login" class="create-account-mobile-btn">Create Account</button></div>
    </div>
      
    <div class="row login-row">
        <div class="col-lg-4 col-md-4 col-sm-12 form-section">
            <p class="login-header">Let your joy begin</p>
            <p class="login-title"> Create your account </p>

            <div class="signup-space">
                
                <p>1 of 3</p>
            </div>
            <div class="progress" style="height: 9px; margin-bottom: 50px;">
                <div class="progress-bar" role="progressbar" style="width: 25%; background: #007DC1 !important;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
            </div>


            <div class="form">
            <form action="" method="post">
                    <input class="form-control email" id="fname" type="text" name="email" placeholder="First Name">
                    <input class="form-control email" id="lname" type="text" name="email" placeholder="Last Name">
                    <input class="form-control email" id="email" type="text" name="email" placeholder="Email">
                    <input class="form-control email" id="phone" type="text" name="email" placeholder="Phone number">
                


              <div class="form-btn">
                <button type="submit"  name="login" class="next-classic-btn">Next</button>
              </div>
                
            </form>
        </div>
        </div>
        
        <div class="col-lg-4 offset-lg-4 col-md-4 offset-md-4 col-sm-12 login-background">
            <img src="images/RSS-H-1.png" class="login-logo" alt="">
             
            
            <p class="create-p">Have an account? <a href="<?php //echo base_url('login'); ?>">Sign In</a></p>
            <p class="text-p">Download the App</p>

            <div class="button">
              <button type="button" class="btn btn-dark btn-lg"><i class="fab fa-apple"></i> on the App store </button>
              <button type="button" class="btn btn-outline-dark btn-lg"><i class="fab fa-google-play"></i> on Google play </button>

            </div>
        </div>

         

       
    </div>

</div>--->

<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>

<script src="<?php echo base_url(); ?>assets/js/script.js"></script>

<script src="<?php echo base_url(); ?>assets/js/user-registration.js?version=<?php echo rand(1, 99999999); ?>.10.<?php echo rand(1, 4050); ?>"></script>