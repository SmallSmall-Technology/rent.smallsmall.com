   
    <div class="verification-form">
        <div class="details">
            <h1>Employment details</h1>
            <p class="beforeyou">Before you can subscribe with us we need to know who you are since this will be a long partnership. We do not share data with any 3rd party or government agency.</p>
            <p>3 of 5</p>
        </div>
        <div class="progress" style="height: 9px; width: 100%;">
            <div class="progress-bar" role="progressbar" style="width: 60%; background: #007DC1 !important;" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <div class="form">
            <form  id="employmentForm" class="verificationForm regForm" method="POST">
                <div class="row">
                    <div class="col">
                        <select name="employment-status" class="customSelect employment_status verify-txt-f" id="employment-status">

						    <option value="" selected="selected">Employment status</option>

						    <option value="Employed">Employed</option>

						    <option value="Unemployed" >Unemployed</option>

						</select>
                    </div>
                    <div class="col">
                        <input type="text" class="form-control job_title verify-txt-f" placeholder="Occupation/Job Title">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control company_name verify-txt-f" placeholder="Company Name">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control manager_hr_name verify-txt-f" placeholder="HR's Full Name">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control manager_hr_email verify-txt-f" placeholder="HR's Email Address">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control manager_hr_phone verify-txt-f" placeholder="HR's Phone">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <textarea class="form-control company_address verify-txt-f" rows="5" placeholder="Company address"></textarea>
                    </div>
                    <div class="col">
                        
                    </div>
                </div>
                <div class="form-topic">Guarantor details</div>
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control guarantor_name verify-txt-f" placeholder="Full name/Relationship">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control guarantor_email verify-txt-f" placeholder="Email">
                    </div>
                </div>
                <div class="row">
                    <div class="col">

						<input type="text" class="form-control guarantor_phone verify-txt-f" placeholder="Telephone">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control guarantor_job_title verify-txt-f" placeholder="Job title/Occupation">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control guarantor_address verify-txt-f" placeholder="Full Address">
                    </div>
                    <div class="col">
                        
                    </div>
                </div>
                <button type="submit" id="verifyBut" class="btn btn-primary verifyBut" style="width: 308px;">Next</button>
            </form>
        </div>
        
          
    </div>
<script src="<?php echo base_url().'assets/js/verification.js' ?>"></script>