	
    <div class="verification-form">
        <div class="details">
            <h1>Personal details</h1>
            <p class="beforeyou">Before you can subscribe with us we need to know who you are since this will be a long partnership. We do not share data with any 3rd party or government agency.</p>
            <p>1 of 5</p>
        </div>
        <div class="progress" style="height: 9px; width: 100%;">
            <div class="progress-bar" role="progressbar" style="width: 20%; background: #007DC1 !important;" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <div class="form">
            <form id="profileVerification" method="post" autocomplete="off">
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control verify-txt-f" id="first-name" placeholder="First Name">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control verify-txt-f" id="last-name" placeholder="Last Name">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control verify-txt-f" id="email" placeholder="Email">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control verify-txt-f" id="phone" placeholder="Phone">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control verify-txt-f" id="gross-pay" placeholder="Net monthly income">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control verify-txt-f dob" id="dob" placeholder="Date of birth" onfocus="(this.type='date')" >
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <select id="customSelect" class="marital-status">
                            
                            <option>Marital Status</option>
                            
                            <option value="single">Single</option>

							<option value="married">Married</option>

							<option value="divorced">Divorced</option>

							<option value="widowed">widowed</option>
							
                        </select>
                    </div>
                    <div class="col">
                        <select id="customSelect" class="gender">
                        
                            <option>Gender</option>
                            
                            <option value="Male">Male</option>
                            
                            <option value="Female">Female</option>
                        
                        </select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col">
                        <select id="customSelect" class="country verify-txt-f">
							<option value="" selected="selected">Country</option>
							    <?php

									$CI =& get_instance();

									$countries = $CI->get_countries();

									foreach($countries as $country => $value){

										echo '<option value="'.$value['id'].'">'.$value['name'].'</option>';

									}

							    ?>
						</select>
                    </div>
                    <div class="col">
                        <select id="customSelect" class="verify-txt-f states">

							<option value="">State</option>

						</select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control verify-txt-f" disabled id="city" placeholder="City/Town">
                    </div>
                    <div class="col">
                        <input type="text" id="passport-number" class="form-control verify-txt-f" placeholder="Passport number (or drivers licence, voter's card)">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="text" id="linkedin-url" class="form-control" placeholder="Linkedin URL">
                    </div>
                    <div class="col">
                        
                    </div>
                </div>
                <button type="submit" id="verifyBut" class="btn btn-primary verifyBut" style="width: 308px;">Next</button>
            </form>
        </div>
        
          
    </div>

<script src="<?php echo base_url().'assets/js/verification.js' ?>"></script>

<script src="<?php echo base_url().'assets/js/country-picker.js' ?>"></script>

<script src="<?php echo base_url().'assets/js/state-picker.js' ?>"></script>