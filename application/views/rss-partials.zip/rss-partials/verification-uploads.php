	<div class="verification-form">
        <div class="details">
            <h1>Verify me</h1>
            <p class="beforeyou">Before you can subscribe with us we need to know who you are since this will be a long partnership. We do not share data with any 3rd party or government agency.</p>
            <h4>Upload document</h4>
            <p>5 of 5</p>
        </div>
        <div class="progress" style="height: 9px; margin-bottom: 50px;">
            <div class="progress-bar" role="progressbar" style="width: 100%; background: #007DC1 !important;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        
        
        <form id="uploadForm" class="verificationForm regForm" method="POST" enctype="multipart/form-data">
            <div class="row">
                
                <div class="col-sm-4 pdf-wrapper">
                    <h2>Bank Statement</h2>
                    <span class="accepted">Accepted file types: PDF</span>
                    <div class="dropboxes pdf">
                        <div class="drag-area" id="dropzone-bank">
                            <div class="icon">
                                <img src="<?php echo base_url(); ?>assets/images/upload.svg" alt="">
                            </div>
    
                            <span class="header">Drag and drop files,</span>
                            <span class="header">or<span class="button">  Browse</span></span>
                            <input type="file" class="statement-inp" data-multiple-caption="{count} files selected" hidden>
                            <!-- <span class="support">Supports: JPEG, JPG, PNG</span> -->
                        </div>
                        
                    </div>
                    <div class="file-name">

						<div id="statement-fileName" class="fileName"></div>

					</div>

					<div class="progress-container" id="statement-progress">

						<div class="meter">

							<div class="meter-text" id="statement-meter-text"></div>

							<span id="statement-progress-bar" style="width:0%"></span>

						</div>

						<!---<div class="cancel-upload" id="bank-cancel"><i class="fa fa-times"></i></div>--->					

					</div>
                </div>
                
                <div class="col-sm-4 image-wrapper">
                    <h2>Valid ID ( Intl. passport, Driver’s license or National ID )</h2>
                    <span class="accepted">Accepted file types: JPG, JPEG, PNG, GIF, PDF</span>
                    <div class="dropboxes imagedrop">
                        <div class="drag-area" id="dropzone-id">
                            <div class="icon">
                                <img src="<?php echo base_url(); ?>assets/images/upload.svg" alt="">
                            </div>
    
                            <span class="header2">Drag and drop files,</span>
                            <span class="header2">or<span class="button2"> Browse</span></span>
                            <input class="input2 identification-inp" type="file" data-multiple-caption="{count} files selected" hidden>

                            
                            <!-- <span class="support">Supports: JPEG, JPG, PNG</span> -->
                        </div>
                    </div>
                    <div class="file-name">

						<div id="id-fileName" class="fileName"></div>

					</div>

					<div class="progress-container" id="id-progress">

						<div class="meter">

							<div id="id-meter-text" class="meter-text"></div>

							<span id="id-progress-bar" style="width:0%"></span>

						</div>

						<!---<div class="cancel-upload" id="id-cancel"><i class="fa fa-times"></i></div>--->

					</div>
                </div>

                <div class="col-sm-8">


                    

                    <div class="radio"><input name="terms-use-link" type="radio" /></div>
                    <div class="label">I agree that the submission of this information does not guarantee that RentSmallSmall will offer this property to me and that RentSmallSmall may reject the application without giving any reasons. Term of Use</div>
                    <div class="clear"></div>
                    <div class="radio"><input name="tenancy-term" type="radio" /></div>
                    <div class="label">I have read and agreed to the Subscription terms, and a personalized copy will be sent to me via email before I move into the property.</div>
                </div>
                
            </div>

                
                <input type="hidden" id="userID" value="<?php echo @$userID; ?>" />
        
        		<input type="hidden" id="statement" value="" />
        
        		<input type="hidden" id="idcard" value="" />
        
        		<input type="hidden" id="statement-state" value="0" />
        
        		<input type="hidden" id="id-state" value="0" />
        	<div class="row backnext">
                <div class="col"><button type="button" class="btn btn-primary">Back</button></div>
                <div class="col"><button type="submit" class="btn btn-primary">Finish</button></div>
            </div>
        
    	</div>
	</form>
</div>
	
	<!---<div class="pane">

		<div class="pane-inner">

			<h1>Upload files</h1>

			<span class="breadcrumbs">Profile > Renting history > Employment > File upload</span>

			<h5>

				Our final stage of your verification process requires you share you bank details for us to ascertain you can maintian rental payment of our property. 

			</h5>

		</div>

	</div>

	<div class="item-pane overflow-div">

		<div class="page-inner overflow-div">

			<form id="uploadForm" class="verificationForm regForm" method="POST" enctype="multipart/form-data">--->

				<!--<div class="regFormHead">Profile</div>-->

				<!---<div class="form-field-wrapper overflow-div">

					<div class="input-container left">

						<label>Valid ID ( Intl. passport, Driver’s license or National ID only )</label>

						<div class="disclaimer">Accepted file types: JPG, JPEG, PNG, PDF</div>

						

						<div class="dropzone js" id="dropzone-id">

							<div class="box" id="box-id">

								<input type="file" name="file-5" id="file-5" class="inputfile inputfile-4 identification-inp" data-multiple-caption="{count} files selected" />

								<label for="file-5"><figure><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/></svg></figure> <span>Choose a file&hellip;</span></label>

							</div>

												

						</div>	

						<div class="file-name">

							<div id="id-fileName" class="fileName"></div>

						</div>

						<div class="progress-container" id="id-progress">

							<div class="meter">

								<div id="id-meter-text" class="meter-text"></div>

								<span id="id-progress-bar" style="width:0%"></span>

							</div>

							<div class="cancel-upload" id="id-cancel"><i class="fa fa-times"></i></div>

						</div>

					</div>

					<div class="input-container right">

						<label>Bank statement (You can upload more than one file)</label>

						<div class="disclaimer">Accepted file types: JPG, JPEG, PNG, PDF</div>

						<div class="dropzone js" id="dropzone-bank">

							<div class="box" id="box-statement">

								<input type="file" name="file-6" id="file-6" class="inputfile inputfile-4 statement-inp" data-multiple-caption="{count} files selected"  />

								<label for="file-6"><figure><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/></svg></figure> <span>Choose a file&hellip;</span></label>

							</div>								

						</div>							

						<div class="file-name">

							<div id="statement-fileName" class="fileName"></div>

						</div>

						<div class="progress-container" id="statement-progress">

							<div class="meter">

								<div class="meter-text" id="statement-meter-text"></div>

								<span id="statement-progress-bar" style="width:0%"></span>

							</div>

							<div class="cancel-upload" id="bank-cancel"><i class="fa fa-times"></i></div>					

						</div>

					</div>

					

					<div class="input-container-full overflow-div">

						<label class="full_container">

							<div for="terms-use-link" class="label-text">I agree that the submission of this information does not guarantee that RentSmallSmall will offer this property to me and that RentSmallSmall may reject the application without giving any reasons. <a target="_blank" href="<?php //echo base_url('terms-of-use'); ?>">Terms of use</a></div>

						  	<input name="terms-use-link" type="checkbox" checked="checked">

						  	<span class="checkmark"></span>

						</label>

						

						<label class="full_container">

							<div class="label-text">I have read and agreed to the <a target="_blank" href="<?php //echo base_url('tenancy-terms'); ?>">Tenancy terms</a>, and a personalized copy will be sent to me via email before I move into the property.</div>

						  	<input name="tenancy-term" type="checkbox" checked="checked">

						  	<span class="checkmark"></span>

						</label>

						

					</div>

					<input type="hidden" id="userID" value="<?php //echo @$userID; ?>" />

					<input type="hidden" id="statement" value="" />

					<input type="hidden" id="idcard" value="" />

					<input type="hidden" id="statement-state" value="0" />

					<input type="hidden" id="id-state" value="0" />

				</div>---->

				

					<!--<div class="forgot-pass"><a href="#">Forgot password?</a></div>-->
				<!---<div class="form-field-wrapper overflow-div">
					<button class="verifyBut-left">Back</button>

					<button class="verifyBut-right verifyBut" id="verifyBut-right">Submit</button>
				</div>--->
				

				<!--<div class="form-field-wrapper">

					<div class="pp-container left">

						We value your privacy.<br />

						By signing up, you accept  our <a href="#">Terms of Use</a> and <a href="#">Privacy Policy</a>

					</div>

				</div>-->

			<!---</form>

		</div>

	</div>--->

<!--<script>

	$('.verifyBut').css("background", "#CCC");

</script>-->


            <script>
                 
                var baseUrl = "https://rent.smallsmall.com/";
                
                let button = document.querySelector('.button');
                let input = document.querySelector('input');

                let button2 = document.querySelector('.button2');
                let input2 = document.querySelector('.input2');

                let file;
                let file2;

                button.onclick = () =>{
                    input.click();
                };

                button2.onclick = () =>{
                    input2.click();
                };
                
                input2.addEventListener('change', function() {
                	"use strict";
                	var fd = new FormData();
                	var files = $(this)[0].files[0];
                	var folderName = $('#userID').val();
                	var filepath = "";
                	
                	//alert(files[0].name);
                	
                	//return false;
                	
                	fd.append('files',files);        
                	$.ajax({
                		xhr: function() {
                			var xhr = new window.XMLHttpRequest();
                			xhr.upload.addEventListener("progress", function(evt) {
                				if (evt.lengthComputable) {
                					var percentComplete = ((evt.loaded / evt.total) * 100);
                					$("#id-progress-bar").css("width", percentComplete + '%');
                					
                					if(percentComplete === 100){
                					    
                					    $('#id-state').val(1);
                					    
                					}
                				}
                			}, false);
                			return xhr;
                		},
                		url: baseUrl+'rss/uploadIdentification/'+folderName,
                		type: 'post',
                		data: fd,
                		contentType: false,
                		processData: false,
                		beforeSend: function(){
                			$('#id-meter-text').html("Uploading...");
                		},
                		success:function(data, folder, pictures){
                			filepath = folderName+'/'+files.name.replace(/\s+/g, '_');
                			$('#id-meter-text').html("Done");
                			$('#id-fileName').html("<span style='color:green;'>Successful upload</span>");
                			$('#idcard').val(filepath);
                
                		}
                	});
                });
                input.addEventListener('change', function() {
                	"use strict";
                	var fd = new FormData();
                	var files = $(this)[0].files[0];
                	var folderName = $('#userID').val();
                	var filepath = "";
                	
                	//alert(files[0].name);
                	
                	//return false;
                	
                	fd.append('files',files);        
                	$.ajax({
                		xhr: function() {
                			var xhr = new window.XMLHttpRequest();
                			xhr.upload.addEventListener("progress", function(evt) {
                				if (evt.lengthComputable) {
                					var percentComplete = ((evt.loaded / evt.total) * 100);
                					$("#statement-progress-bar").css("width", percentComplete + '%');
                					if(percentComplete === 100){
                					    
                					    $('#statement-state').val(1);
                					    
                					}
                					
                				}
                			}, false);
                			return xhr;
                		},
                		url: baseUrl+'rss/uploadIdentification/'+folderName,
                		type: 'post',
                		data: fd,
                		contentType: false,
                		processData: false,
                		beforeSend: function(){
                			$('#statement-meter-text').html("Uploading...");
                		},
                		success:function(data, folder, pictures){
                			filepath = folderName+'/'+files.name.replace(/\s+/g, '_');
                			$('#statement-meter-text').html("Done");
                			$('#statement-fileName').html("<span style='color:green;'>Successful upload</span>");
                			$('#statement').val(filepath);
                
                		}
                	});
                });

                //when browse
                /*input.addEventListener('change', function() {
                    file = this.files[0];
                    pdf.classList.add('active');
                    displayFile();
                });

                input2.addEventListener('change', function() {
                    file2 = this.files[0];
                    imagedrop.classList.add('active');
                    displayFile2();
                });

                

                function displayFile() {
                    let fileType = file.type;
                    // console.log(fileType);
                    let validExtensions = ['application/pdf'];

                    if(validExtensions.includes(fileType)){
                        let fileReader = new FileReader();

                        fileReader.onload = () => {
                            let fileURL = fileReader.result;
                            // console.log(fileURL);
                            let imgTag = `<img class="preview-image" src="images/pdf.png" alt="">`;
                            pdf.innerHTML = imgTag;
                        };
                        fileReader.readAsDataURL(file);
                    } else {
                        alert('This file is not a pdf')
                        dragText.textContent = 'Drag and Drop';
                        pdf.classList.remove('active');
                    }
                }

                function displayFile2() {
                    let fileType2 = file2.type;
                    // console.log(fileType);
                    let validExtensions2 = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'application/pdf'];

                    if(validExtensions2.includes(fileType2)){
                        let fileReader2 = new FileReader();

                        fileReader2.onload = () => {
                            let fileURL2 = fileReader2.result;
                            // console.log(fileURL);
                            if(fileType2 == 'application/pdf'){
                                let imgTag2 = `<img class="preview-image2" src="images/pdf.png" alt="">`;
                                imagedrop.innerHTML = imgTag2;
                            }else{
                                let imgTag2 = `<img class="preview-image2" src="${fileURL2}" alt="">`;
                                imagedrop.innerHTML = imgTag2;
                            }
                            //let imgTag2 = `<img class="preview-image2" src="${fileURL2}" alt="">`;
                            
                        };
                        fileReader2.readAsDataURL(file2);
                    } else {
                        alert('This file format is not accepted')
                        dragText2.textContent = 'Drag and Drop';
                        imagedrop.classList.remove('active');
                    }
                }*/
            </script>

<script src="<?php echo base_url().'assets/js/verification.js' ?>"></script>

<script src="<?php echo base_url().'assets/js/upload-verification-file.js' ?>"></script>

<script src="<?php echo base_url().'assets/js/custom-file-input.js' ?>"></script>