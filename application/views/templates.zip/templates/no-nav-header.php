<!doctype html>

<html>

<head>

<meta charset="utf-8">

<meta name="viewport" content="width=device-width">
<meta name="description" content="Pay monthly rent when you rent an apartment, we made it easy and flexible for affordable houses for rent in Lagos Nigeria ">

<meta name="keywords" content="Monthly rent in Lagos Nigeria,Real Estate,Realtor,monthly rent payment,Home rental in Lagos Nigeria,home">

<link rel="icon" type="image/png" href="<?php echo base_url(); ?>assets/img/favicon.png">

<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" />

<link href="<?php echo base_url(); ?>assets/css/font.awesome.min.css" rel="stylesheet" />

<link href="<?php echo base_url(); ?>assets/css/side-nav.css" rel="stylesheet" />

<link href="<?php echo base_url(); ?>assets/css/custom-drop-down.css" rel="stylesheet" />

<link href="<?php echo base_url(); ?>assets/css/custom-drop-down-2.css" rel="stylesheet" />

<link href="<?php echo base_url(); ?>assets/css/custom-checkbox.css" rel="stylesheet" />

<link href="<?php echo base_url(); ?>assets/css/custom-uploader.css" rel="stylesheet" />

<link href="<?php echo base_url(); ?>assets/css/tool-tip.css" rel="stylesheet" />	

<link href="<?php echo base_url(); ?>assets/css/testimonial-carousel.css" rel="stylesheet" />

<script src="<?php echo base_url(); ?>assets/js/jquery-1.11.0.min.js" type="application/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/AjaxFileUpload.js"></script>

<script src="<?php echo base_url(); ?>assets/js/header-animate.js" type="application/javascript"></script>
    
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/multi-animated-counter.js"></script>
<style>
	.no-nav-header{
		width:100%;
		min-height:50px;
		overflow:auto;
		padding-top:5px;
		padding-bottom:5px;
	}
	.no-nav-logo{
		width:120px;
		overflow:auto;
		margin:auto;
	}
	.no-nav-logo a{
		display:block;
		width:100%;
		height:auto;
	}
	.no-nav-logo a img{
		width:100%;
		height:auto;
	}
	.payment-result-box{
		margin:auto;
		width:400px;
		min-height:200px;
		overflow:auto;
	}
	.payment-result{
		width:100%;
		min-height:10px;
		overflow:auto;
		font-family:avenir-bold;
		font-size:28px;
		color:#000;
		text-align:center;
		margin-bottom:10px;
	}
	.payment-detail{
		width:100%;
		line-height:30px;
		font-family:avenir-bold;
		color:#000;
		text-align:center;
	}
	.payment-detail-s{
		width:100%;
		line-height:30px;
		font-family:avenir-regular;
		color:#000;
		text-align:center;
		font-size:14px;
	}
	.micro-detail{
		width:100%;
		min-height:10px;
		overflow:auto;
		margin-top:40px;
		margin-bottom:30px;
		font-family:avenir-regular;
		font-size:12px;
		text-align:center;
	}
	.dash-but{
		width:250px;
		line-height:40px;
		margin:auto;
	}
	.dash-but a{
		display:block;
		width:100%;
		height:100%;
		background:#00CDA6;
		color:#03100D;
		text-decoration:none;
		font-family:avenir-bold;
		text-align:center;
		border-radius:5px;
	}
</style>
<!-- remove this if you use Modernizr -->

<script>(function(e,t,n){var r=e.querySelectorAll("dropzone")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>

<title><?php echo $title; ?></title>

</head>



<body>
<div class="no-nav-header">
	<div class="no-nav-logo"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/img/logo-rss.png" /></a></div>
</div>