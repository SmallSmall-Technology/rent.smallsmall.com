
</body>	

<script src="<?php echo base_url(); ?>assets/js/sidebar-form.js" type="application/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/testimonial-carousel.js" type="application/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/custom-drop-down.js" type="application/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/top-form.js" type="application/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/menu-opener.js" type="application/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/header-animate.js" type="application/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/rating-meter.js" type="application/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/wallet-payment.js" type="application/javascript"></script>

</html>